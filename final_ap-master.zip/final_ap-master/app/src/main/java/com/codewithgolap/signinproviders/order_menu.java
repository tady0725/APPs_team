package com.codewithgolap.signinproviders;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class order_menu extends AppCompatActivity {
    String TAG = "mExample";
    RecyclerView mRecyclerView;
    MyListAdapter myListAdapter;
    SwipeRefreshLayout swipeRefreshLayout;
    ArrayList<HashMap<String,String>> arrayList = new ArrayList<>();
    ArrayList<HashMap<String,Integer>> arrayList2 = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_menu);

        //製造資料
        makeData();

        //設置RecycleView
        mRecyclerView = findViewById(R.id.recycleview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        myListAdapter = new MyListAdapter();
        mRecyclerView.setAdapter(myListAdapter);
        //下拉刷新
        swipeRefreshLayout = findViewById(R.id.refreshLayout);
        swipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.blue_RURI));
        swipeRefreshLayout.setOnRefreshListener(()->{
            arrayList.clear();
            makeData();
            myListAdapter.notifyDataSetChanged();
            swipeRefreshLayout.setRefreshing(false);

        });
    }//onCreate

    int[] imgId={R.drawable.p1,R.drawable.p2,R.drawable.p3,R.drawable.p4,R.drawable.p5,R.drawable.p5, R.drawable.p7,R.drawable.p8,R.drawable.p9,R.drawable.p10};
    String[] imgName ={"五更腸旺","客家小炒", "鹹蛋苦瓜", "白灼蝦", "宮保雞丁", "椒鹽杏鮑菇", "鳳梨蝦球", "蒜泥白肉", "滑蛋蝦仁", "蔥爆牛肉"};

    private void makeData() {
        for (int i = 0; i<10 ;i++){
            HashMap<String,String> hashMap = new HashMap<>();
            HashMap<String,Integer> HashMap2 = new HashMap<>();


            hashMap.put("Id","菜名:"+imgName[i]);


            HashMap2.put("srcCompat",i);

            //hashMap.put("Sub2",String.valueOf(new Random().nextInt(80) + 20));
            //hashMap.put("Avg",String.valueOf(
            //(Integer.parseInt(hashMap.get("Sub1"))
            //+Integer.parseInt(hashMap.get("Sub2")))/2));

            arrayList.add(hashMap);
        }
    }



    //R.string.resource_150
    private class MyListAdapter extends RecyclerView.Adapter<MyListAdapter.ViewHolder>{

        String menu = "";

        class ViewHolder extends RecyclerView.ViewHolder{
            private TextView tvId,getn;
            private ImageView tvSub1;
            private Button btnadd, btnadd_checkout,clear,view_list;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                //菜名
                tvId = itemView.findViewById(R.id.textView_Id);

                tvSub1 = itemView.findViewById(R.id.imageView1);
                // 數量
                getn = itemView.findViewById(R.id.editTextNumberSigned);
                //添加至購物車
                btnadd = itemView.findViewById(R.id.buyp1);
                // 結帳
                btnadd_checkout = itemView.findViewById(R.id.checkout);
                //清除
                clear=itemView.findViewById(R.id.clear_orderlist);
                //查看當前購物車
                view_list=itemView.findViewById(R.id.view_order_list);

                //btnadd_checkout.setVisibility(View.INVISIBLE);

                // 點擊查看購物車
                view_list.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(menu.isEmpty()){
                            Toast.makeText(view.getContext(),//tvId.getText() +
                                    "購物車為空，請先選購餐點" ,Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(view.getContext(),//tvId.getText() +
                                    "當前購物車 :"+"\n"+menu ,Toast.LENGTH_SHORT).show();
                        }

                    }
                });

                // 點擊清除購物車
                clear.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(view.getContext(),//tvId.getText() +
                                "清除購物車" ,Toast.LENGTH_SHORT).show();
                        menu="";
                    }
                });
                // 點擊結帳時
                btnadd_checkout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(menu.isEmpty()){
                            Toast.makeText(view.getContext(),//tvId.getText() +
                                    "購物車為空無法結帳，請先選購餐點" ,Toast.LENGTH_SHORT).show();
                        }
                        else {
                            Toast.makeText(view.getContext(),//tvId.getText() +
                                    "前往結帳，兩秒後跳轉", Toast.LENGTH_SHORT).show();

                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            Bundle bundle=new Bundle();
                            bundle.putString("order",menu);
                            Intent intent=new Intent();
                            intent.setClass(order_menu.this,sql.class);
                            intent.putExtras(bundle);
                            startActivity(intent);


                        }
                    }
                });

                // 點擊加入購物車時
                btnadd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Toast.makeText(view.getContext(),
                                "成功加入 " + tvId.getText() + getn.getText(),Toast.LENGTH_SHORT).show();


                        menu = menu + tvId.getText() + getn.getText() + "\t";
                    }
                });

            }
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.recycle_item,parent,false);
            return new ViewHolder(view);
        }



        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

            holder.tvId.setText(arrayList.get(position).get("Id"));
            holder.tvSub1.setImageResource(imgId[position]);


        }



        @Override
        public int getItemCount() {
            return arrayList.size();
        }
    }



}
