package com.codewithgolap.signinproviders;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class order_preview extends AppCompatActivity {
    private TextView tv;
    private Button send;
    private EditText n,ads;
    String all_order="";
    //String add="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_preview);
        tv= findViewById(R.id.show_all_order);
        send=findViewById(R.id.send);
        n=findViewById(R.id.number);
        ads=findViewById(R.id.address);
        send.setOnClickListener(ls2);

        Intent intent=this.getIntent();
        Bundle bundle =intent.getExtras();

        String od =bundle.getString("order");
        all_order=od;
        tv.setText(od);
    }

    private  Button.OnClickListener ls2 =new Button.OnClickListener()
    {
        public  void onClick(View v)
        {

            String num =ads.getText().toString();

            String add =n.getText().toString();
            if(num.isEmpty() && add.isEmpty())
            {
                Toast.makeText(getApplicationContext(),"請先輸入地址與電話", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"兩秒後跳轉", Toast.LENGTH_SHORT).show();
                Bundle bundle=new Bundle();
                bundle.putString("Num",num);
                bundle.putString("Add",add);
                bundle.putString("all_order",all_order);




                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Intent intent2=new Intent();
                intent2.putExtras(bundle);
                intent2.setClass(order_preview.this,sql.class);
                startActivity(intent2);

            }




        }

    };
}