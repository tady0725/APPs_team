package com.codewithgolap.signinproviders;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class sql extends AppCompatActivity {

    // creating variables for our edittext, button and dbhandler
    private EditText courseNameEdt, courseTracksEdt, courseDurationEdt, courseDescriptionEdt;
    private Button addCourseBtn, readCourseBtn ;
    private TextView ts;
    private DBHandler_db dbHandler;
    String all_order="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sql);

        // initializing all our variables.
        courseNameEdt = findViewById(R.id.idEdtCourseName);
        courseTracksEdt = findViewById(R.id.idEdtCourseTracks);
        courseDurationEdt = findViewById(R.id.idEdtCourseDuration);
        courseDescriptionEdt = findViewById(R.id.idEdtCourseDescription);
        addCourseBtn = findViewById(R.id.idBtnAddCourse);
        readCourseBtn = findViewById(R.id.idBtnReadCourse);


        Intent intent=this.getIntent();
        Bundle bundle =intent.getExtras();

        String od =bundle.getString("order");
        all_order=od;
        ts=findViewById(R.id.tshow_order);
        ts.setText("目前菜單有:"+od);


        // creating a new dbhandler class
        // and passing our context to it.
        dbHandler = new DBHandler_db(sql.this);

        // below line is to add on click listener for our add course button.
        addCourseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(sql.this, "", Toast.LENGTH_LONG).show();
                Toast toast= Toast.makeText(getApplicationContext(),
                        "若無增加餐點，第四欄位無須再填入", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.TOP| Gravity.CENTER_HORIZONTAL, 0, 0);
                toast.show();
                // below line is to get data from all edit text fields.
                String courseName = courseNameEdt.getText().toString();
                String courseTracks = courseTracksEdt.getText().toString();
                String courseDuration = courseDurationEdt.getText().toString();
                String courseDescriptions = courseDescriptionEdt.getText().toString();
                //接收
                String courseDescription = od +courseDescriptions;


                // validating if the text fields are empty or not.
                /*if(courseDuration.isEmpty())
                {
                    Toast.makeText(sql.this, "選擇自取,請在地址欄未填寫自取", Toast.LENGTH_SHORT).show();
                    return;
                }*/
                if (courseName.isEmpty() && courseTracks.isEmpty() && courseDuration.isEmpty()) {// && courseDuration.isEmpty()
                    Toast.makeText(sql.this, "請填選所有欄位", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {


                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                dbHandler.addNewCourse(courseName, courseDuration, courseDescription, courseTracks);

                // after adding the data we are displaying a toast message.
                Toast.makeText(sql.this, "新增成功 ~", Toast.LENGTH_SHORT).show();
                courseNameEdt.setText("");
                courseDurationEdt.setText("");
                courseTracksEdt.setText("");
                courseDescriptionEdt.setText("");
                }
            }
        });

        readCourseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // opening a new activity via a intent.
                Intent i = new Intent(sql.this, ViewCourses_db.class);
                startActivity(i);
            }
        });
    }
}
