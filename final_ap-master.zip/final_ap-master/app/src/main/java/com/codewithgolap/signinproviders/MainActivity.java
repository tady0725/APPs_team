package com.codewithgolap.signinproviders;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    FirebaseUser currentUser ;
    private Button order,readdata,query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        order= findViewById(R.id.order);
        readdata = findViewById(R.id.readdata);
        query=findViewById(R.id.query);
        order.setOnClickListener(ls1);
        readdata.setOnClickListener(ls);
        query.setOnClickListener(ls2);




        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(Html.fromHtml("<font color=\"black\">"+getString(R.string.profile)+"</font>"));
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // ini firebase 抓下
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        userData();
    }
    // 使用者資訊
    public void userData() {
        CircleImageView userImage = findViewById(R.id.userImage);
        TextView userName = findViewById(R.id.userName);
        TextView userEmail = findViewById(R.id.userEmail);

        userName.setText(currentUser.getDisplayName());
        userEmail.setText(currentUser.getEmail());

        if (currentUser.getPhotoUrl() != null){
            Glide.with(this).load(currentUser.getPhotoUrl()).into(userImage);
        }
        else {
            Glide.with(this).load(R.drawable.avatarr).into(userImage);
        }
    }

    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(getApplicationContext(),EmailAndPasswordLoginActivity.class);
        startActivity(intent);
        finish();
    }
    private  Button.OnClickListener ls =new Button.OnClickListener()
    {
        public  void onClick(View v)
        {
         //跳轉天氣
            Intent intent1=new Intent();
            intent1.setClass(MainActivity.this,jsonapi.class);
            startActivity(intent1);



        }

    };
    private  Button.OnClickListener ls1 =new Button.OnClickListener()
    {
        public  void onClick(View v)
        {
            //跳轉點餐
            Intent intent=new Intent();
            intent.setClass(MainActivity.this,order_menu.class);
            startActivity(intent);

        }

    };
    private  Button.OnClickListener ls2 =new Button.OnClickListener()
    {
        public  void onClick(View v)
        {
            //跳轉點餐
            Intent intent2=new Intent();
            intent2.setClass(MainActivity.this,DB_data.class);
            startActivity(intent2);

        }

    };
}